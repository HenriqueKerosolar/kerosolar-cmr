# Origem

Peça **nova**, desenhada em 31/10/2026 a partir da especificação do dono (`Motor_Conector_Especificacao_Mind.docx`, v1.0) e da auditoria do ecossistema do mesmo dia. Nome escolhido pelo dono: **Nervo** (antes "Motor Conector"; a ideia veio de "KeroNervo" em `Tarizi/docs/ECOSSISTEMA_ARQUITETURA_DECISOES.md` §5, sem o "Kero").

Não é cópia de código de nenhum produto. Reaproveita **contratos e formatos** de peças existentes, reimplementados dentro da peça para não criar dependência entre peças:

| Contrato reaproveitado | Peça de referência | Como ficou compatível |
|---|---|---|
| Rotas de IA do Mind (`/api/machine/capabilities/:key/execute`, `/api/machine/jobs`) e formato `kmk_` | `keromind-client` 0.1.0; `Ai DEV Orquestrator/src/platform/http/routes/machine.ts`, `machineJobs.ts` | mesmas rotas, mesmo formato de Key, mesmo tratamento de erros; resposta com `costBrl` lida do `main` do Mind |
| Envelope de evento | `contracts-core` 0.1.0 (`envelope.ts`) | mesmos campos e regras de nome (`dominio.fato`) |
| Assinatura `t=,v1=` e anti-replay | `webhook-security` 0.1.0 (`signature.ts`) | mesmo HMAC sobre `${t}.${corpo}`, mesma tolerância (300 s) |
| Caixa de saída com lease e backoff; fila de mortos | `outbox-relay`, `job-engine` | mesma semântica; armazenamento por porta (Postgres no produto, memória por padrão) |
| Repetição segura e `Idempotency-Key` | `sdk-base` | mesma regra (só repete o que é idempotente) |

Escolha de projeto: peça **autossuficiente** (sem importar outras peças), porque a Biblioteca distribui por `file:` por versão congelada e as peças não declaram dependência entre si. Divergências conscientes: a assinatura e o envelope foram duplicados aqui em vez de importados; se `contracts-core` ou `webhook-security` mudarem de contrato, o Nervo precisa de uma versão nova.

Lado servidor (Nervo Central): ainda não existe no Mind. As rotas `/api/machine/nervo/*` estão especificadas em `CONTRATO.md` e implementadas só no Central falso de teste.

## 0.3.0 (31/10/2026): pareamento automático

Pedido do dono: "não quero mais copiar Key/segredo/variáveis na Vercel; todo sistema novo deve nascer assim". Desenho em conversa com o dono: ele só aceita no Mind; o sistema recebe a credencial direto. Padrão de referência: o fluxo de "código de dispositivo" (device authorization) do OAuth 2.0, adaptado: o pedido é anônimo e inofensivo, a credencial só nasce na busca de quem prova ter o token (`pollToken`) DEPOIS do aceite humano. Lado do Mind: `docs/NERVO_PAREAMENTO.md` (repositório do Mind). Selagem: AES-256-GCM + HKDF-SHA256 de `node:crypto` (nada de dependência nova).

## 0.4.0 (01/11/2026): hora oficial

Pedido do dono: o Mind passa a ser a referência de hora do ecossistema (Brasília) e o dono precisa de log correto no horário de Brasília. Motivo concreto: telas do Aulyn 3 h adiantadas na Vercel (UTC) e crons contando em UTC. A medida do desvio usa o ponto médio da chamada (como NTP simplificado: offset = servidor − (saída + chegada)/2). A formatação em si mora na peça `fuso-horario`; aqui ficam só ~30 linhas de `Intl` (offset do fuso e ISO com offset), duplicadas de propósito para o Nervo seguir autossuficiente.
