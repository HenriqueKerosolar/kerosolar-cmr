# Contrato do Nervo 0.4.2

Duas metades: a **peça** (o que o produto chama) e o **Nervo Central** (o que o Mind precisa implementar). O Central falso em `src/testing/fakeCentral.ts` é a especificação executável do lado servidor; o Central real deve passar nos mesmos cenários (`test/e2e.test.ts`, `test/ai.test.ts`).

## 1. API da peça

`createNervo(options): Nervo`

| Opção | Obrigatória | Descrição |
|---|---|---|
| `baseUrl` | sim | Endereço do Central. `https://`; `http://` só localhost/127.0.0.1/[::1]/*.localhost. Sem usuário, consulta ou fragmento |
| `key` | não na criação | `kmk_...`. Vem do ambiente do host. Troca com `setKey` (rotação) |
| `product` | sim | `{ id, name?, version, environment }`. `id` em minúsculas/hífen; `environment` ∈ development, sandbox, staging, production |
| `installationId` | sim | Identificador estável da instalação |
| `tenant` | não | Tenant padrão dos eventos e chamadas |
| `provides.events` | não | Se informado, publicar outro tipo é recusado |
| `inbound.secrets` | não | Segredo(s) de entrega (lista, para rotação; 16+ caracteres cada; **únicos por instalação**). Sem eles, tudo que chega é recusado |
| `inbound.allowedTenants` | não | Se informado, tenant fora da lista é recusado (403) antes do handler |
| `inbound.handlerTimeoutMs` | não | Tempo máximo de um handler (padrão 45 s, máximo 55 s) |
| `inbound.onUnhandled` | não | Evento sem handler: `retry` (503, padrão — o evento não se perde numa subida lenta) ou `ack` (200, descarta) |
| `maxResponseBytes` | não | Resposta máxima do Central (padrão 25 MB: cabe áudio/imagem em base64). Lida em fluxo e cortada no limite |
| `inbound.url` | não | URL pública que o Central usa para entregar |
| `outbox`, `inbox` | não | Armazenamentos (ver seção 4). Padrão: memória |
| `fetch`, `now`, `sleep`, `timer`, `random`, `newId`, `log` | não | Portas. Padrão: globais do Node |
| `timeoutMs`, `retries`, `backoff*`, `maxEventAttempts`, `breaker*` | não | Padrões: 30 s, 2, 250 ms–5 s, 12 tentativas, disjuntor 5 falhas/30 s |

Superfície devolvida: `ai.{execute, submitJob, getJob, waitJob, runJob}`, `events.{publish, flush, on, deadLetters, requeue, stats}`, `calls.{invoke, handle}`, `receive`, `announce`, `capabilities`, `usage`, `whoami`, `health`, `startFlusher`, `setKey`, `hasKey`.

### Erros (`NervoError.code`)

| Código | Quando | Repetível |
|---|---|---|
| NERVO_CONFIG | opção inválida na criação | não |
| NERVO_INVALID | entrada inválida (tipo de evento, tenant, payload, capacidade, chave de idempotência) | não |
| NERVO_AUTH | 401, ou Key ausente | não (o evento fica pendente até a Key ser trocada) |
| NERVO_FORBIDDEN | 403 (escopo ou tenant) | não |
| NERVO_NOT_FOUND | 404 | não |
| NERVO_BUDGET | 402 (teto de custo) | não |
| NERVO_RATE_LIMIT | 429 | sim |
| NERVO_UNAVAILABLE | rede, qualquer 5xx, 408, 409, 425, ou resposta 200 sem a confirmação esperada | sim |
| NERVO_TIMEOUT | tempo esgotado | sim |
| NERVO_ABORTED | cancelado pelo chamador | não |
| NERVO_CIRCUIT_OPEN | disjuntor aberto | sim |
| NERVO_PAYLOAD | payload ou resposta grande demais | não |
| NERVO_REJECTED | 4xx de pedido ruim / redirecionamento. Dentro de um handler, só `NervoRejection` (lançada de propósito, ou `reject("motivo")`) é recusa de negócio; qualquer outro erro vira falha repetível | não |
| NERVO_JOB_FAILED | trabalho de IA falhou | conforme `retryable` |

Limites: payload de evento e input de chamada ≤ 64 KiB, profundidade ≤ 16, nós ≤ 10.000; corpo recebido ≤ 256 KiB; mensagem de erro do servidor truncada em 300 caracteres. O disjuntor só conta falha do Central (rede, 5xx, tempo esgotado), nunca erro de uso nem limite de taxa.

## 2. Contrato HTTP do Nervo Central (Mind)

Autenticação: `Authorization: Bearer kmk_...` (Key por instalação), sempre. **Uma Key pertence a exatamente um tenant**: o Central recusa (403) evento ou chamada de outro tenant. Sistema que atende vários clientes usa uma instalação/Key por cliente. Respostas de erro: `{ "error": "...", "retryable": bool? }`. Toda rota de escrita aceita `Idempotency-Key` e, repetida com a mesma chave e o MESMO corpo, **não executa nem cobra de novo** (devolve a resposta anterior). A mesma chave com OUTRO corpo é erro de uso: **422**, nunca a resposta de outra operação.

### 2.1 Já existentes no Mind (a peça usa como estão)

| Rota | Escopo | Uso |
|---|---|---|
| `GET /healthz` | — | saúde (sem Key) |
| `GET /api/machine/whoami` | qualquer | identidade da Key |
| `POST /api/machine/capabilities/:key/execute` | `capabilities:execute` | IA síncrona. Corpo = pedido da capacidade + `correlationId?`, `maxCostUsd?`. Resposta com `costUsd`, `costBrl`, `exchange`, `text`, `json`, `audio`, `files`... |
| `POST /api/machine/jobs` `{capability, body}` → 202 `{jobId}` | `capabilities:execute` | trabalho longo |
| `GET /api/machine/jobs/:id` → `{status: running\|succeeded\|failed, result?, error?, retryable?}` | `capabilities:execute` | consulta |

**Lacunas conhecidas do Mind (precisam de trabalho no Central; a peça já se comporta como se existissem):** `Idempotency-Key` em `execute` e `jobs` (hoje repetir duplica custo); reserva atômica do teto de custo, que deve valer **incluindo o custo da própria chamada**; aviso de término de job.

### 2.2 Novas rotas do Nervo Central (a construir no Mind)

Prefixo `/api/machine/nervo`. Escopos novos: `nervo:announce`, `nervo:events:publish`, `nervo:calls:invoke`, `nervo:read`.

| Rota | Corpo | Resposta | Regras |
|---|---|---|---|
| `POST /announce` | `{ nervoVersion, product:{id,name?,version,environment}, installationId, inboundUrl?, provides:{events:[{type}]}, consumes:{events:[{type}]} }` | `{ installationId, status:"registered" }` | Atualiza o cadastro (repetir é seguro). **`inboundUrl` é alvo de requisição do Central: validar `https`, recusar IP privado/loopback/link-local (SSRF) e nunca seguir redirecionamento** |
| `POST /events` | `{ envelope }` (ver 3) | `{ accepted:true, duplicate:bool, routedTo:n }` ou `{accepted:false,error}`. **Só `accepted:true` confirma o envio** (200 sem isso é tratado como indisponibilidade) | `envelope.tenant` **deve** ser o da Key (senão 403). Dedup por (instalação, `envelope.id`). Entrega a quem assina o tipo no mesmo tenant. Falha de entrega é reentregue pelo Central |
| `POST /calls` | `{ target, operation, input, tenant, callId, correlationId }` | `{ status:"ok", result }` | `tenant` = o da Key (senão 403). Destino precisa estar anunciado no mesmo tenant (senão 404). Repetição com mesmo `callId` não executa de novo |
| `GET /capabilities` | — | `{ installationId, scopes, systems:[...] }` | Só o que a Key pode ver |
| `GET /usage` | — | `{ installationId, costUsd, costBrl, ... }` | Só da própria instalação |

### 2.3 Entrega do Central para o sistema (rota do próprio produto, `inbound.url`)

`POST` com corpo JSON e cabeçalho `x-nervo-signature: t=<unix>,v1=<hex>`, onde `v1 = HMAC-SHA256(segredo_de_entrega, "<t>.<corpo cru>")` (mesmo formato da peça `webhook-security`). Tolerância de relógio: 300 s.

- Evento: `{ "kind":"event", "installationId", "envelope": {...} }`
- Chamada: `{ "kind":"call", "installationId", "callId", "operation", "input", "tenant", "correlationId" }`

`installationId` é a instalação de **destino**, dentro do corpo assinado e **obrigatório**: o receptor recusa (403) entrega feita para outra instalação (impede reenviar a B uma entrega assinada para A, mesmo que os segredos coincidam). O segredo de entrega deve ser único por instalação.

**A cada reentrega o Central reassina com timestamp NOVO** (a assinatura original vence em 300 s).

Respostas do produto: `200 {status: processed|duplicate|ignored}` (sucesso — não reenviar); `401` assinatura inválida; `403` destino ou tenant não permitido (não reenviar); `400` entrega malformada (não reenviar); `409` em processamento (reenviar); `422` recusa de negócio ou conflito de id (não reenviar); `500`/`503 {retryable:true}` (reenviar com backoff; 503 = ainda sem handler).

**Efeito único:** a chave de deduplicação é `tenant + id` (eventos) e `tenant + operação + callId` (chamadas), junto com um resumo do conteúdo. Mesmo id com conteúdo diferente = conflito 422, nunca o resultado de outra entrega. Envelope recebido **sem `id`, `version` ou `correlationId`** é recusado (400): a peça nunca sorteia um id.

## 3. Envelope de evento

Campos idênticos ao `EventEnvelope` da peça `contracts-core`: `id`, `type` (`dominio.fato`, minúsculas, sem `.vN`), `version`, `tenant`, `occurredAt` (ISO-8601 UTC com milissegundos), `correlationId`, `causationId`, `aggregate?`, `payload` (objeto JSON). Chave desconhecida é erro. Dinheiro no payload: inteiro em centavos ou string decimal, nunca float.

## 4. Armazenamento durável (portas)

A versão em memória perde dados ao reiniciar. Produto com requisito de durabilidade injeta `OutboxStore` / `InboxStore` próprios. Semântica exigida:

- `OutboxStore.add` é idempotente por `id` (devolve `false` se já existe).
- `claimDue` reserva registros com **lease** (dois workers nunca pegam o mesmo): em SQL, `UPDATE ... WHERE status='pending' AND next_attempt_at<=now AND lease_until<=now ... RETURNING` (ou `SELECT ... FOR UPDATE SKIP LOCKED`).
- `markSent` / `markRetry` / `markDead` / `requeue` mudam estado e limpam o lease.
- `InboxStore.tryStart` é atômico por id: `started` (com um `token` de DONO), `duplicate` (com a resposta guardada) ou `in_progress`; `complete(id, token, ...)` só grava se o token ainda é o dono; `release(id, token)` só libera a reserva do próprio dono. A reserva dura 60 s.
- A peça só chama `release` quando o handler falhou ANTES de produzir efeito. Depois do efeito ela nunca libera: se registrar a conclusão falhar, responde falha repetível e a reserva expira sozinha (**o handler pode rodar de novo nesse caso raro, por isso handlers devem ser idempotentes**).
- As versões em memória descartam as linhas concluídas mais antigas acima de 10.000 e **avisam em produção** (`environment: 'production'`) que não são duráveis.

Implementação pronta em Postgres: `import { createPostgresOutbox, createPostgresInbox, nervoPostgresSchemaSql } from '@lib/nervo/postgres'` (a 0.2.0 em diante), com o `query(sql, params)` do host. A DDL vem de `nervoPostgresSchemaSql()` (ou por modelos Prisma mapeados nas mesmas tabelas/colunas). Chame `purgeNervoPostgres(query, <ms>)` de tempos em tempos (ex.: no mesmo cron do flush) para apagar enviados/concluídos antigos. Tabelas sugeridas (para outros bancos): `nervo_outbox(id pk, envelope jsonb, status, attempts, next_attempt_at, lease_until, created_at, sent_at, last_error)` e `nervo_inbox(id pk, state, until, response, done_at)`. Sempre dentro do isolamento por cliente do produto (RLS), com o `tenant` no envelope.

## 5. Segurança (o que a peça faz e o que o host faz)

A peça: redação de segredos, falha fechada, assinatura em tempo constante, janela anti-replay, resposta única para qualquer falha de assinatura, validação estrita de entrada, sem redirecionamento, sem segredo em URL, sem segredo em log.

**Um handler por evento/operação** (sem execução parcial de vários). Handler de versão específica (`lead.won.v1`) tem preferência sobre o genérico (`lead.won`).

O host: guardar a Key e o segredo de entrega no cofre/ambiente (nunca no repositório, no navegador ou no app mobile — o Nervo roda no **servidor** do produto), expor a rota de entrega só por HTTPS, passar o corpo **cru** ao `receive`, rotacionar segredos pela lista e por `setKey`.

## 6. Não incluído

OpenAPI 3.1 gerado (o contrato desta seção é a fonte por enquanto); cliente .NET/PHP (usar o contrato HTTP direto); backends SQL prontos para as caixas; chamada assíncrona entre sistemas (as chamadas são síncronas); assinatura de eventos por consulta (pull); testes contra o Mind real (o Central falso é a referência até o Central do Mind existir).

## 7. Pareamento automático (0.3.0)

Objetivo: **ninguém copia Key, segredo de entrega nem variável**. O sistema só configura o ENDEREÇO do Mind. O dono faz UM aceite no painel do Mind; o Mind entrega a credencial direto ao sistema, que a guarda cifrada no próprio banco. O contrato completo do lado do Mind (estados, limites, ameaças) está em `docs/NERVO_PAREAMENTO.md` do repositório do Mind; aqui, o que a peça faz e exige.

### 7.1 API

`createNervoConnection(options): Connection`

| Opção | Obrigatória | Descrição |
|---|---|---|
| `mindUrl` | sim | Endereço do Mind (`https`; `http` só localhost). Pode ser uma função, lida a cada passada (endereço estável / descoberta quando o Mind mudar de lugar). Mudar o endereço NÃO exige novo pareamento |
| `product`, `installationId` | sim | Como em `createNervo` |
| `inbound.url` | sim | URL pública onde o Mind entrega. É o que o dono confere ao aceitar |
| `store` | sim | `ConnectionStore` (Postgres do produto em produção: `createPostgresConnectionStore(query)`; memória em testes) |
| `seal.secrets` | sim | Segredo(s)-base (**32+ caracteres, aleatórios**) para cifrar a credencial. Use um que o sistema JÁ tem (ex.: o de sessão): o HKDF não fortalece segredo fraco. O primeiro cifra; todos tentam abrir |
| `outbox`, `inbox`, `provides`, `fetch`, `now`, `sleep`, `timer`, `random`, `newId`, `log`, `timeoutMs`, `retries`, `backoff*`, `maxEventAttempts`, `breaker*`, `maxResponseBytes` | não | Iguais a `createNervo` |
| `renewFraction` | não | Renova a Key quando faltar menos desta fração da validade (padrão 1/3) |
| `retryAfterExpiredMs` | não | Depois de pedido que venceu, só pede de novo passado este tempo (padrão 30 min) |
| `minAdvanceIntervalMs` | não | `advance()` repetido dentro deste intervalo não fala com o Mind (padrão 30 s) |

Superfície: `status()` (só lê o banco local), `advance({ restart? })`, `nervo()`, `publish`, `flush`, `tick` (advance + flush: o cron DIÁRIO), `tickIfStale` (0.4.2; ver seção 9), `receive` (entrada), `on`, `handle`, `forget`.

Estados (`status.state`): `paired`, `pending` (com `userCode`), `denied`, `expired`, `ended`, `revoked`, `seal_error`, `unconfigured`, `unreachable`. A `message` é pronta para mostrar a quem administra e nunca contém Key nem segredo.

### 7.2 O que a peça garante

- **Credencial só selada**: AES-256-GCM, chave HKDF-SHA256 derivada do segredo-base + contexto `<installationId>|<espaço>`; valor adulterado, segredo errado ou espaço trocado = `NERVO_SEAL` (falha fechada). Sem `seal.secrets` válido a criação falha.
- **Gravar antes de usar**: a Key recebida é guardada antes de qualquer outra chamada. Se guardar falhar, o pedido continua e a busca seguinte (janela de 5 min no Mind) recebe outra Key, revogando a órfã.
- **Resposta do Mind validada**: Key no formato `kmk_`, `installationId` igual ao nosso, tenant e segredos de entrega no formato; fora do contrato nada é guardado.
- **Nunca insiste contra o dono**: depois de `denied` ou `revoked` só `advance({ restart: true })` ("Conectar de novo") faz novo pedido; `revoked` é gravado e a peça PARA de bater (cada 401 vira alarme no Mind). Pedido vencido só se repete depois de `retryAfterExpiredMs`.
- **Exclusão mútua** (`tryLock`) em tudo que muda o estado (pedir/buscar, renovar): duas invocações simultâneas fazem um só pedido e uma só renovação.
- **Renovação**: `POST /api/machine/nervo/credential/renew` com a Key atual quando faltar menos de `renewFraction` da validade; grava a nova (com retentativas) antes de trocar em memória; a antiga expira em ~10 min no Mind. Uma renovação cuja resposta se perdeu é substituída pelo Mind na tentativa seguinte.
- **Sem corrida entre instâncias**: tudo que altera a conexão guardada (renovar, adotar segredo, atualizar validade, marcar revogada) relê o banco sob a exclusão `conn` e aplica só a diferença: uma Key mais velha nunca sobrescreve a mais nova, e um 401 com a Key antiga NÃO marca `revoked` se o banco já tem a Key renovada por outra instância. A exclusão do pareamento dura 120 s (maior que o pior caso de uma busca).
- **Segredo de entrega (adoção confirmada pelo sistema)**: o `announce` carrega `deliverySecretVersion` (a que o sistema GUARDOU) e devolve `deliverySecretVersion` (a do Mind) e `deliverySecretAdoptionPending`. Se a do Mind é maior, a peça busca (`GET /delivery-secret` → `[nova, anterior...]`; buscar NÃO adota), GUARDA, e só então um novo `announce` confirma; com `deliverySecretAdoptionPending: false` busca de novo e larga os antigos (guarda só a corrente). Se guardar falhar, a confirmação não é enviada e o Mind continua assinando com a versão que o sistema tem.
- **Nunca lança por indisponibilidade**: erro de rede/proxy (inclusive 403/404/418 de túnel) vira `unreachable`. Um 404 só significa "o Mind esqueceu o pedido" se vier com o corpo do Mind (`pedido de pareamento não encontrado`); o 404 de um túnel fora do ar NÃO apaga o token de busca nem abandona um aceite já dado.
- **Prova de posse**: `advance({ restart: true })` envia a Key atual (se não revogada) no novo pedido, e cancela o pedido pendente anterior no Mind.
- **Endereço**: a Key só é enviada ao endereço configurado AGORA; a credencial vale para o Mind, não para a URL.
- **Sem conexão**: `receive` responde 503 repetível (o Mind reenvia); `publish` lança `NERVO_UNPAIRED` (sem tenant não há envelope válido: o produto decide; eventos publicados antes do pareamento terminar não são enfileirados); `flush` devolve resumo vazio.
- **Redação**: `kmk_...`, `Bearer ...`, assinaturas e o token de busca `kmp_...` nunca aparecem em erro, estado ou log.

### 7.3 Rotas do Mind que a peça usa (todas sem Key, exceto as duas últimas)

| Rota | Uso |
|---|---|
| `POST /api/nervo-pairing/requests` | `{ product:{id,name?,version,environment}, installationId, inboundUrl, nervoVersion }` → 201 `{ pairingId, pollToken, userCode, expiresAt, intervalSeconds }`. NÃO é repetível (repetir substituiria o pedido anterior) |
| `GET /api/nervo-pairing/requests/:id` | `Authorization: Bearer <pollToken>` → `pending` \| terminal (`denied`, `expired`, `superseded`, `cancelled`, `gone`) \| `approved` com `credential:{token,expiresAt,scopes}`, `workspaceId`, `installationId`, `deliverySecrets[]`, `deliverySecretVersion`. 404 igual para id inexistente e token errado; 429 `slow_down` |
| `DELETE /api/nervo-pairing/requests/:id` | o sistema desiste (melhor esforço) |
| `GET /api/machine/nervo/delivery-secret` | `nervo:announce` → `{ version, secrets[] }` |
| `POST /api/machine/nervo/credential/renew` | `nervo:announce` → `{ token, expiresAt }` (no máximo 1 por hora) |

O `announce` passa a devolver também `deliverySecretVersion` e `credentialExpiresAt`.

### 7.4 Armazenamento da conexão

`ConnectionStore`: `get(slot)`, `put(slot, selado)`, `delete(slot)`, `tryLock(nome, ttlMs, agora)`, `unlock(nome)`. Guarda só texto OPACO (já selado). Espaços usados: `connection` (credencial) e `pairing` (pedido pendente com o token de busca). Contrato executável: `test/connectionStoreContract.ts` (memória sempre; Postgres opt-in com PGlite). Postgres: tabela `nervo_connection(slot pk, sealed, updated_at, lease_until)`; `tryLock` por `INSERT ... ON CONFLICT ... WHERE lease_until <= agora`.

### 7.5 Limites conhecidos

- A gravação da Key renovada é repetida 3 vezes; se o banco ficar indisponível durante TODAS as tentativas e a Key antiga vencer (10 min), o sistema fica sem Key: recuperação por `advance({ restart: true })` e novo aceite. (Se só a resposta se perder, o Mind substitui a renovação não usada.)
- Trocar o segredo-base sem mantê-lo na lista `seal.secrets` invalida a credencial guardada (novo pareamento).
- Sem descoberta automática do Mind: `mindUrl` (ou função que o produto fornece).

## 8. Hora oficial do Mind (0.4.0)

O Mind é a referência de hora do ecossistema. Regra: **guardar sempre em UTC (ISO com `Z`) e MOSTRAR no fuso do workspace** (padrão `America/Sao_Paulo`). A peça `fuso-horario` (Biblioteca) faz a formatação; esta seção é o contrato com o Mind.

### 8.1 Rota e campos do Mind
| Rota / campo | Descrição |
|---|---|
| `GET /api/machine/nervo/time` (`nervo:read`) | `{ nowUtc, timezone, offsetMinutes, nowLocal }`: hora oficial em UTC, fuso do workspace da Key, deslocamento em vigor e a hora local com offset (`2026-11-01T08:24:50.123-03:00`). `Cache-Control: no-store` |
| `announce` → `serverTimeUtc`, `timezone` | campos NOVOS e OPCIONAIS na resposta (peça antiga os ignora; Mind antigo não os devolve) |

### 8.2 API da peça
- `nervo.time({ refresh? })` → `NervoTime { nowUtc, timezone, offsetMinutes, nowLocal, skewMs, rttMs, syncedAt, source }`. `nowUtc` = relógio local + desvio medido (a hora do MIND, não a do servidor onde o sistema roda). Sem medida ainda, ou com `refresh`, chama `GET /time`; senão usa a medida guardada.
- `nervo.clock()` → `{ skewMs, rttMs, syncedAt, timezone, source } | undefined` (sem rede).
- `connection.time()` (exige conexão ativa: `NERVO_UNPAIRED`); `ConnectionStatus.clockSkew { skewMs, rttMs, syncedAt, warning? }` e `ConnectionStatus.timezone`.

### 8.3 Medida do desvio
`skewMs = relógio local − relógio do Mind` (positivo = local ADIANTADO), com o servidor lido no PONTO MÉDIO da chamada: erro máximo = metade do `rttMs`. Ignorados: resposta com mais de 15 s de ida e volta, `serverTimeUtc` que não seja ISO UTC (`...Z`) e `timezone` desconhecido (mantém o anterior). A medida se atualiza a cada `announce()`.

### 8.4 Aviso
|desvio| > 60 s → `clockSkew.warning` em português ("O relógio deste servidor está 3 min 30 s adiantado em relação ao Mind..."); > 300 s acrescenta que as entregas assinadas são recusadas (tolerância anti-replay de 300 s). Sincronize o relógio do servidor (NTP) ou use `nervo.time()` para a hora oficial.

### 8.5 Limites
A hora oficial é a do Mind no instante da medida somada ao tempo decorrido no relógio LOCAL (monotonicidade e deriva dependem dele): reavalie com `time({ refresh: true })` ou pelo próximo anúncio. Não substitui NTP para o sistema operacional.

## 9. Quando atualizar (0.4.2): por evento, não por relógio

Regra do dono: **não temos recursos para ficar gastando**. O Nervo atualiza QUANDO ALGO MUDA e, no máximo, num cron **diário** de segurança. Serverless e banco serverless cobram por acordar.

- **Por evento:** publicar → `flush()` na hora; abrir a tela de status → `tickIfStale()`; botão "Verificar agora" → `tickIfStale({ force: true })`; entrada do Mind → `receive()`.
- **`tickIfStale({ maxAgeMs = 300000, force = false })`** → `{ status, flushed?, skipped? }`. Passada recente (e o estado não é `pending`): **zero** idas ao Mind e **zero** acessos ao banco; devolve o último resultado com `skipped: true`. Com `pending` o limite cai para 10 s. Simultâneas dividem uma passada. Falha sobe o erro e NÃO conta como passada feita. `maxAgeMs` inválido (negativo, `NaN`): `NERVO_CONFIG`. A memória é por processo; `forget()` e `advance({ restart: true })` a zeram; `tick()` a alimenta.
- **Cron:** um só, **diário** (`tick()`): renova a Key a tempo, reenvia a caixa presa, limpa. **Nunca** em minutos.
- **O que a peça não faz:** não agenda nada sozinha e não tem laço de fundo; quem agenda é o sistema, e este contrato diz quanto.
