# Nervo

Motor de integração do ecossistema. **Todo sistema nosso carrega o Nervo** para duas coisas:

1. **Usar a IA do Orquestrador/Mind com uma Key** (`kmk_...`), sem ter chave de provedor própria.
2. **Conversar com os outros sistemas** (Avendo, Mind Marketing, Mide Fiscal, Aulyn, Taziri...) por eventos e chamadas autorizadas, sempre passando pelo Nervo Central (o Mind), que confere permissão, isola por cliente, mede e audita.

Peça sem dependências (só `node:crypto`), TypeScript puro, Node >= 22.18. Rede, relógio, armazenamento e logger entram por parâmetro.

## Uso mínimo

```ts
import { createNervo } from '@lib/nervo'

const nervo = createNervo({
  baseUrl: process.env.NERVO_URL!,            // endereço do Mind (https; http só em localhost)
  key: process.env.NERVO_KEY,                  // kmk_... emitida no Mind para ESTA instalação
  product: { id: 'avendo', version: '1.4.0', environment: 'production' },
  installationId: 'avendo-prod-001',
  tenant: 'empresa-a',                         // cliente dono dos eventos
  provides: { events: [{ type: 'lead.won' }, { type: 'lead.created' }] },
  inbound: { url: 'https://avendo.exemplo/nervo', secrets: [process.env.NERVO_DELIVERY_SECRET!] },
})

// 1) IA (síncrona e trabalho longo)
const r = await nervo.ai.execute('text_generation', { text: 'Resuma este lead' }, { idempotencyKey: 'resumo-L100' })
console.log(r.text, r.costBrl)
const video = await nervo.ai.runJob('video_generation', { text: '...' })   // vídeo, audiobook etc.

// 2) Publicar um fato (nunca derruba o produto se o Mind estiver fora: fica na caixa de saída)
await nervo.events.publish('lead.won', { leadId: 'L100', valorCentavos: 250000, gclid: 'abc' })
nervo.startFlusher()                           // reenvia o que ficou preso

// 3) Receber fatos e chamadas de outros sistemas (ligue ao endpoint HTTP do produto)
nervo.events.on('payment.confirmed', async (e) => { /* gera a nota; seja idempotente; reject("motivo") = recusa de negócio, sem reenvio */ })
nervo.calls.handle('attribution.lookup', (input) => ({ origem: 'google-ads' }))
// no endpoint POST /nervo:  const out = await nervo.receive({ headers, body: corpoCru }); res.status(out.status).json(out.body)

// 4) Chamar outro sistema
const origem = await nervo.calls.invoke('marketing', 'attribution.lookup', { leadId: 'L100' })

await nervo.announce()                         // apresenta o sistema ao Central (catálogo)
```

## O que o Nervo garante

- **Segredo nunca vaza:** a Key só vai no cabeçalho `Authorization`; qualquer `kmk_...`, `Bearer ...` ou assinatura é removido de mensagens de erro e logs.
- **Falha fechada:** sem Key não sai chamada; sem assinatura válida nada recebido é lido ou executado.
- **Efeito único:** evento ou chamada entregue duas vezes executa uma vez (caixa de entrada, por tenant + id; id reutilizado com outro conteúdo é conflito, nunca o resultado de outro). Envio repetido não duplica (caixa de saída com id estável). Só `accepted:true` do Central confirma um envio.
- **Entrega só para quem é destino:** a entrega assinada leva o `installationId` de destino; entrega feita para outra instalação é recusada.
- **Não perde fato:** com o Mind fora do ar, `publish` não lança; o evento fica pendente e sai depois. Falha permanente vai para a fila de mortos, com o motivo, e um humano decide (`requeue`).
- **Repetição segura:** só repete o que é seguro (GET, ou POST com chave de idempotência). Nunca repete operação sem chave.
- **Isolamento por cliente:** todo evento e chamada leva `tenant`; o Central recusa tenant que não é o da Key.
- **O produto não depende do Mind para o essencial:** disjuntor, tempo limite e fila local. Só as funções que dependem de IA ou de outro sistema degradam.

## Conexão automática (0.3.0): sem copiar Key nem segredo

Sistema novo já nasce assim. A única configuração é o endereço do Mind; o resto o Mind entrega depois que o dono aceita (um clique no painel do Mind) e a peça guarda cifrado no banco do próprio sistema.

```ts
import { createNervoConnection } from '@lib/nervo'
import { createPostgresConnectionStore, createPostgresInbox, createPostgresOutbox } from '@lib/nervo/postgres'

const connection = createNervoConnection({
  mindUrl: process.env.NERVO_MIND_URL,                      // a ÚNICA configuração; pode ser função
  product: { id: 'marketing', name: 'Mind Marketing', version: '1.0.0', environment: 'production' },
  installationId: 'marketing-prod',
  inbound: { url: 'https://meusistema.com/api/nervo/inbound' },
  store: createPostgresConnectionStore(query),              // tabela nervo_connection (nervoPostgresSchemaSql())
  seal: { secrets: [process.env.SESSION_SECRET!] },         // um segredo que o sistema JÁ tem
  outbox: createPostgresOutbox(query), inbox: createPostgresInbox(query),
})
connection.on('lead.won', async (e) => { /* ... */ })

// cron DIÁRIO (nunca em minutos: veja "Quando rodar o tick()") e/ou ao abrir a tela de status: pede o pareamento, busca, renova a Key, adota segredo novo, envia a caixa de saída
await connection.tick()
await connection.tickIfStale()   // da tela: não faz nada (nem toca o banco) se a última passada tem menos de 5 min

// tela de status do sistema (lê só o banco local)
const s = await connection.status()  // { state: 'pending', userCode: 'K7QX-29MD', message: 'Aguardando o aceite do dono…' }

// endpoint de entrada
await connection.receive({ headers, body: rawBody })
// publicar
await connection.publish('lead.captured', {...})
// IA
const n = await connection.nervo(); await n?.ai.execute(...)
```

Depois de uma recusa ou revogação a peça NÃO insiste: a tela do sistema oferece "Conectar de novo" (`connection.advance({ restart: true })`). Contrato: `CONTRATO.md` seção 7.

## Quando rodar o tick() (0.4.2): quando ALGO MUDA, nunca por relógio

**Regra do dono: não temos recursos para ficar gastando.** O Nervo de todo sistema atualiza **quando algo muda** (evento, ação de quem usa, abrir a tela de status), e no máximo UM cron **diário** de segurança. Banco serverless (Neon) e Vercel cobram por ACORDAR: um cron a cada poucos minutos mantém o banco acordado o dia inteiro sem ninguém usar o sistema.

| Quando | O que chamar |
|---|---|
| O sistema **publica** um evento | `connection.publish(...)` e logo em seguida `connection.flush()` (ou `tick()`): o evento sai na hora |
| Alguém **abre a tela de status** do Nervo | `connection.tickIfStale()`: com pedido pendente, vê se o dono já aceitou (limite de 10 s); estável, não faz nada se a última passada tem menos de 5 min |
| Botão **"Verificar agora"** / "Conectar de novo" | `connection.tickIfStale({ force: true })` / `advance({ restart: true })` |
| **Uma vez ao dia** (cron) | `connection.tick()`: renova a Key a tempo, reenvia a caixa presa, limpa. É a rede de segurança, não o motor |
| Chega um evento do Mind | nada: `connection.receive(...)` já é por evento |

**NUNCA** agende `tick()` em minutos (`*/5 * * * *`, `* * * * *`). Um cron diário (ex.: `0 9 * * *`, 06:00 de Brasília) basta: a Key vale muito mais que um dia e a peça renova com antecedência.

`tickIfStale({ maxAgeMs?, force? })` existe para isto: chamado de telas e do boot, **não faz nada e não toca o banco** quando a última passada é recente (padrão 5 min), então uma tela que recarrega ou vários usuários abrindo a página não viram rajada de consultas. Chamadas simultâneas dividem uma só passada. Devolve `{ status, flushed?, skipped? }`; `skipped: true` = nada foi feito agora. A memória da última passada é **por processo**: numa função serverless nova o primeiro `tickIfStale` roda de verdade, e isso é intencional.

## Hora oficial do Mind (0.4.0)

O Mind é a referência de hora do ecossistema: **guarde sempre em UTC e mostre no fuso do workspace** (padrão horário de Brasília; peça `fuso-horario`).

```ts
const t = await nervo.time()           // { nowUtc, timezone: 'America/Sao_Paulo', nowLocal: '2026-11-01T08:24:50.123-03:00', skewMs, ... }
nervo.clock()                          // última medida do desvio (sem rede)
const s = await connection.status()    // s.timezone, s.clockSkew?.warning  ("O relógio deste servidor está 3 min adiantado em relação ao Mind...")
```
O desvio do relógio (`skewMs`) é medido a cada anúncio, pelo ponto médio da chamada, e avisa em português quando passa de 60 s.

## Caixas duráveis (serverless, Vercel, qualquer produto que reinicia)

```ts
import { createNervo } from '@lib/nervo'
import { createPostgresInbox, createPostgresOutbox } from '@lib/nervo/postgres'

const query = async (sql: string, params: unknown[] = []) => ({ rows: (await prisma.$queryRawUnsafe(sql, ...params)) as Record<string, unknown>[] })
const nervo = createNervo({ /* ... */ outbox: createPostgresOutbox(query), inbox: createPostgresInbox(query) })
// logo depois de publicar (por evento) e no cron DIÁRIO:  await nervo.events.flush()
```

Crie as tabelas uma vez com `nervoPostgresSchemaSql()`. Em serverless não há `startFlusher`: chame `flush()` logo depois de publicar e num cron DIÁRIO (nunca em minutos).

## Instalar em projeto que não enxerga a Biblioteca

`node D:/Projetos/Biblioteca/scripts/empacotar.mjs nervo --projeto <pasta>` gera `vendor/lib-nervo-<versão>.tgz` (compilado, com tipos). Instale com `"@lib/nervo": "file:vendor/lib-nervo-<versão>.tgz"`.

## Testar sem rede

`@lib/nervo/testing` traz um Nervo Central falso em memória, com as mesmas regras do contrato. Use nos testes do seu produto:

```ts
import { createFakeCentral } from '@lib/nervo/testing'
```

## Documentos

- `CONTRATO.md` — API da peça, contrato HTTP que o Central (Mind) precisa cumprir, portas, limites, armazenamento durável.
- `CHANGELOG.md`, `ORIGEM.md`.
