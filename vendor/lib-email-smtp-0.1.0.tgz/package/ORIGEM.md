# Origem

Peça nova (não extraída). Pedida pelo KeroSolar CRM em 2026-11-06 para notificar novos leads por e-mail (contato@kerosolar.com.br).
Gate 0 consultado ("email", "e-mail", "mail", "smtp", "notificacao"): nada existente. Nenhum projeto tinha envio de e-mail reaproveitável.
Escolha: cliente SMTP sem dependências (em vez de nodemailer) para seguir a regra "zero dependências quando possível".
Riscos: ainda não validada contra servidor SMTP real; TLS real é coberto só pelo `node:tls` padrão (testes usam upgrade injetado).
Consumidores: KeroSolar CRM (via `empacotar.mjs`, deploy no Railway).
