# Changelog — @lib/email-smtp

## 0.1.0 — 2026-11-06
- Primeira versão: SMTP com TLS implícito/STARTTLS, AUTH PLAIN/LOGIN, texto + HTML UTF-8, proteção contra injeção de cabeçalho, recusa de senha sem TLS. 12 testes `node:test` com servidor SMTP falso local (sem rede).
