# @lib/email-smtp

Cliente SMTP mínimo, **sem dependências** (`node:net` / `node:tls`). Envia e-mail texto/HTML em UTF-8.

- TLS implícito (`secure: true`, porta 465) ou **STARTTLS** (porta 587/25).
- `AUTH PLAIN` (preferido) ou `AUTH LOGIN`.
- Por padrão **recusa enviar senha sem TLS** (`requireTls: true`).
- Bloqueia injeção de cabeçalho (CR/LF em assunto/endereços), codifica cabeçalhos UTF-8 (RFC 2047), corpo em base64, dot-stuffing.
- Configuração por injeção: a peça não lê `process.env` e não guarda segredo.

## Uso

```ts
import { enviarEmail } from '@lib/email-smtp'

await enviarEmail(
  { host: 'smtp.exemplo.com.br', port: 587, user: process.env.SMTP_USER, pass: process.env.SMTP_PASS, from: 'Avisos <avisos@exemplo.com.br>' },
  { to: 'contato@exemplo.com.br', subject: 'Novo lead', text: 'Nome: Ana', html: '<b>Nome:</b> Ana' },
)
```

Erros do servidor viram `SmtpError` com `code` (ex.: 535 autenticação, 550 destinatário) e `stage`.
