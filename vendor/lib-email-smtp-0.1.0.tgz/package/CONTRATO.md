# Contrato — @lib/email-smtp 0.1.0

## Entradas
`enviarEmail(cfg: SmtpConfig, msg: EmailMessage, deps?: Deps): Promise<SendResult>`

- `SmtpConfig`: `host`, `port`, `secure?` (TLS implícito), `user?`, `pass?`, `from` ("email" ou "Nome <email>"), `heloName?` (padrão `localhost`), `timeoutMs?` (padrão 20000 por etapa), `rejectUnauthorized?` (padrão `true`), `requireTls?` (padrão `true`).
- `EmailMessage`: `to` (string ou lista), `subject`, `text`, `html?` (gera `multipart/alternative`), `replyTo?`.

## Saídas
`SendResult`: `accepted` (destinatários aceitos), `response` (resposta final do servidor), `messageId`.

## Erros
- `SmtpError { code, stage }` — resposta inesperada do servidor (`code` = código SMTP; 0 = tempo esgotado ou TLS ausente). A mensagem nunca contém o comando enviado (não vaza senha).
- `Error` — configuração/endereço inválido, ou CR/LF em cabeçalho (injeção bloqueada).

## Portas (injetáveis, para teste)
`Deps.connect(cfg)` → socket inicial; `Deps.upgrade(socket, cfg)` → socket TLS após STARTTLS; `Deps.now()` → data do cabeçalho.

## Utilitários exportados
`montarMime`, `prepararData`, `codificarCabecalho`, `enderecoDe`.

## Não faz
Anexos, DKIM, pool de conexões, fila/reenvio. Sem formato persistido (não precisa de migração).
