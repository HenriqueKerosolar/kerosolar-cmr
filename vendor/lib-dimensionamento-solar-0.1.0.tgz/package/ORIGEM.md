# Origem

- Projeto: KeroSolar CRM — `src/lib/crm/belenus/regras.ts` (parte pura do robô de cotação na Belenus) e `cotar.ts` (estrutura de 4 em 4, quantidade de micros, transformador). Regras do dono da KeroSolar (24/11/2026).
- Gate 0: existe `@lib/solar-sizing` (dimensionamento comercial: kWp, preço por tabela/fator, financiamento, economia). Ela não cobre composição de kit (módulo/inversor/cabos/DPS/estrutura). Decisão: peça nova e complementar; a fórmula kWp por HSP aparece nas duas, mas aqui **sem valores padrão** (o host passa HSP/perdas).
- Generalização: o código original lia os objetos da Belenus direto; aqui a escolha recebe a lista já ordenada e um leitor (`LeitorInversor`), para servir a qualquer distribuidor. A ordenação "como o site" e a leitura dos campos da Belenus ficaram em `@lib/conector-belenus`.
- Textos de ajuste: o original dizia "regra do dono"/"Belenus"; agora vêm de `rotulos` (o CRM passa os dele e os textos saem iguais).
- Novidades pedidas pelo dono durante a extração (24/11/2026): fórmula HSP com placas e geração (`dimensionarPorConsumo`, `geracaoEstimada`) e overload preferido/máximo por marca (AUXSOL 50% → 100% antes das outras marcas; não vale no medidor monofásico).
- Ficaram no CRM (específicos do produto): comandos de chat (`cota belenus`, `envia orçamento`), leitura dos campos do lead, texto da nota interna, destino padrão do frete.
- Consumidor: KeroSolar CRM.
