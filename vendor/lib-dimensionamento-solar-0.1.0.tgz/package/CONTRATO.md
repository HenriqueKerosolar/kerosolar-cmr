# Contrato — @lib/dimensionamento-solar 0.1.0

Funções puras, sem efeitos colaterais (entradas não são alteradas; listas devolvidas são cópias).

## Consumo, kWp e geração
- `kwpPorConsumo(kwhMes, metodo)`: `{ metodo: 'hsp', hsp, perdas }` → kWp = consumo / (HSP × 30 × (1 − perdas)); `{ metodo: 'paineis', kwhPorPainel, painelKw }` → ⌈consumo / kWh por painel⌉ × kW do painel. 2 casas; consumo ≤ 0 → 0. **Sem valor padrão.** `RangeError` com parâmetros inválidos.
- `geracaoEstimada(kwpKit, { hsp, perdas })` → `{ mensal, anual }` (mensal = kWp × HSP × 30 × (1 − perdas); anual = mensal × 12; 1 casa).
- `dimensionarPorConsumo(kwh, { hsp, perdas, painelW })` → `{ kwp, placas, kwpKit, geracaoMensal, geracaoAnual }` (placas = ⌈kWp × 1000 / W⌉).

## Módulo e inversor (o host passa a lista NA ORDEM do catálogo)
- `escolherModulo(itens, potenciaW, faixa = { minW: 600, maxW: 700 })` → o primeiro com minW ≤ W < maxW, ou `null`.
- `escolherInversor(itens, leitor, regras = REGRAS_INVERSOR_PADRAO, { limiteKw?, kwpKit?, somenteFaixa? })` → `{ inversor, qtdeSugerida } | { motivo: 'mais-de-um' | 'acima-limite' | 'nenhum' | 'fora-da-faixa' }`. Passos (documentados no código): faixa marca a marca com overload preferido e depois o máximo da marca; exceção do medidor monofásico; último recurso.
- `RegrasInversor`: `overloadPadrao` (padrão 1,5), `overloadPorMarca?` (número ou `{ preferido, maximo? }`; o máximo não vale com `limiteKw`), `overloadMinimoAtende` (padrão 1,3), `ordemMarcas` (padrão AUXSOL > DEYE > SOLIS), `monofasico: { limiteKw (padrão 5), overloadExcecao (padrão 1,85) }`.
- `limiteInversorKw(medidor, ligacaoDaBusca, regras)` → limite só com medidor monofásico em busca não trifásica.
- `escolherMicro(itens, { kw, marca, ehMicro }, { marca })` (o de maior potência, marca preferida primeiro) e `quantidadeMicros(placas, { placasPorMicro })`.

## Componentes
- `calcularStrings(n, { paineisPorString })`, `calcularCabos(strings, { metrosCaboPorString, fracaoVerde })` (verde: 1 string = metros por string; mais strings = ⌈vermelho × fração⌉), `calcularDps(ligacao, { dps? })` (padrão 2 mono/bi, 3 tri).
- `corDoCabo`, `bitolaMm`, `ehDps` (leitura de descrições de catálogo em português).
- `aplicarRegrasComponentes(sugeridos, todos, strings, ligacao, regras, { aplicarDps?, aplicarCabos?, rotulos? })` → `{ pecas, ajustes }` (textos com `rotulos.regra`/`fornecedor`/`fornecedorSujeito`; padrão genérico). Campos extras dos itens são preservados.

## Estrutura e preço
`arredondarEstrutura(n, deN = 4)`; `transformadorPara(medidor, { transformador })`; `valorAoCliente(total, multiplicador, transformador = 0)` (transformador fora da margem; 2 casas).

## Leitura de texto do cliente
`lerLigacao`, `lerTensao`, `lerTelhado`, `PALAVRAS_TELHADO`, `semAcento`.

## Padrões embutidos (técnicos)
Faixa de módulo 600–699 W; overload 1,5 / 1,3; ordem AUXSOL > DEYE > SOLIS; monofásico 5 kW / 1,85; DPS 2/2/3; estrutura de 4 em 4. **Nada comercial** (margem, transformador, cabos, HSP, perdas) tem padrão.

## Não faz
Rede, preços de catálogo, escolha da estrutura do fornecedor. Sem formato persistido.
