# Changelog — @lib/dimensionamento-solar

## 0.1.0 — 2026-11-24
- Primeira versão, extraída do robô Belenus do KeroSolar CRM (`src/lib/crm/belenus/regras.ts`): módulo por faixa, inversor (ordem de marcas, overload preferido/máximo por marca, medidor monofásico com exceção), micro inversor, strings/cabos/DPS, estrutura de N em N, margem e transformador, kWp e geração pela fórmula HSP (e o método por painéis como alternativa). Valores da KeroSolar ficam no CRM. 26 testes `node:test`.
