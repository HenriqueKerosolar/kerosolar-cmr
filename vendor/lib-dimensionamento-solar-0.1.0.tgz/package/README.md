# @lib/dimensionamento-solar

Regras **puras** para montar um kit fotovoltaico on-grid a partir do catálogo de um distribuidor: escolha de módulo e inversor (marcas, overload preferido/máximo, medidor monofásico, micro inversor), strings, cabos, DPS, estrutura, margem/transformador, kWp e geração pelo consumo (fórmula HSP). Sem rede, sem banco, sem relógio, sem dependências.

A peça **não conhece o fornecedor**: o host entrega as listas já na ordem do catálogo e diz como ler cada item (`LeitorInversor`). Valores comerciais e do instalador (margem, transformador, metros de cabo, placas por string, HSP, perdas) entram por parâmetro.

```ts
import { dimensionarPorConsumo, escolherModulo, escolherInversor, REGRAS_INVERSOR_PADRAO, calcularStrings, valorAoCliente } from '@lib/dimensionamento-solar'

const d = dimensionarPorConsumo(500, { hsp: 4.5, perdas: 0.2, painelW: 620 }) // { kwp: 4.63, placas: 8, kwpKit: 4.96, geracaoMensal: 535.7, ... }
const modulo = escolherModulo(modulosOrdenados, (m) => m.potenciaW)            // 1º na faixa 600–699 W
const regras = { ...REGRAS_INVERSOR_PADRAO, overloadPorMarca: { AUXSOL: { preferido: 1.5, maximo: 2 } } }
const inv = escolherInversor(inversoresOrdenados, { kw: (i) => i.kw, marca: (i) => i.fabricante, qtdSugerida: (i) => i.qtd }, regras, { kwpKit: d.kwpKit })
const strings = calcularStrings(8, { paineisPorString: 8 })
const preco = valorAoCliente(custoTotal, 1.6, 600) // margem sobre o custo + transformador fora da margem
```

Detalhes e padrões técnicos em `CONTRATO.md`. Testes: `npm test` (Node >= 22.18, nada a instalar).
