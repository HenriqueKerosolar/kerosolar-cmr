# @lib/proposta-pdf

PDF de proposta comercial / orçamento (A4, layout em caixas com bordas, títulos com linha colorida, tabelas com grade), para **qualquer ramo de negócio**. Recebe os dados já prontos e devolve um `Buffer`. Nenhuma empresa, produto ou texto de ramo fixo no código: empresa, cliente, itens, valores, formas de pagamento, seções opcionais, rótulos e cores entram por parâmetro.

O desenho usa o **pdfkit, injetado pelo host** (`deps.PDFDocument`): a peça não importa o pdfkit, então não traz dependência e o host escolhe a versão.

```ts
import PDFDocument from 'pdfkit'
import { gerarPropostaPdf } from '@lib/proposta-pdf'

const pdf = await gerarPropostaPdf({
  titulo: 'Proposta 2026-001',
  metadados: { titulo: 'Proposta 2026-001 - Ana', autor: 'Empresa Exemplo' },
  empresa: { nome: 'EMPRESA EXEMPLO LTDA', cnpj: '00.000.000/0001-00', endereco: ['Rua A, 1 - Centro'], contatos: ['(00) 0000-0000'], logo: '/caminho/logo.png' },
  emissao: 'Emissão em 01/01/2026, válida por 7 dias.',
  cliente: { nome: 'Ana', cidadeUf: 'Cidade - UF', telefone: '(00) 90000-0000' },
  itens: [{ nome: 'Armário sob medida', fabricante: 'Fábrica X', quantidade: '1 UN' }],
  valores: { total: 15000, linhas: [{ rotulo: '+ Entrega:', valor: 'Inclusa' }], aVista: { valor: 14250, rotulo: 'À vista (5%):', chamada: 'ou R$ 14.250,00 à vista' } },
  pagamentos: { tabelas: [
    { titulo: 'Boleto', cabecalho: ['Prazo', 'Parcela'], linhas: [{ rotulo: '6x', valor: 2600 }] },
    { titulo: 'Cartão', subtitulo: 'Até 3x sem juros', cabecalho: ['Nº', 'Parcela'], colunas: 2, linhas: [{ rotulo: '2x', valor: 7500, marca: 's/ juros' }] },
  ] },
  observacoes: ['Medidas confirmadas na visita técnica.'],
}, { PDFDocument })
```

Seções, na ordem: cabeçalho (logo ou marca em texto + título + dados da empresa), emissão, dados do cliente (+ selo opcional), condição de pagamento*, resumo com tabela*, itens (quebram página), serviços inclusos*, totais (linhas, à vista, valor total), formas de pagamento*, economia/indicadores*, garantias / prazos / validade / nota*, observações*. (*) opcional: ausente = não aparece.

Testes: `npm install` (traz o pdfkit só para os testes) e `npm test` (Node >= 22.18). Contrato completo em `CONTRATO.md`.
