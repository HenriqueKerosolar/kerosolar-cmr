# Contrato — @lib/proposta-pdf 0.1.0

## Entrada
`gerarPropostaPdf(dados: DadosProposta, deps: DependenciasProposta): Promise<Buffer>`

- `deps.PDFDocument` (obrigatório): construtor do pdfkit (`import PDFDocument from 'pdfkit'`, testado com 0.17). A peça chama `new PDFDocument({ size: 'A4', margins, info })` e usa: `font`, `fontSize`, `fillColor`, `strokeColor`, `lineWidth`, `text` (com `continued`), `heightOfString`, `widthOfString`, `save/restore`, `moveTo/lineTo/stroke`, `rect/fill/fillAndStroke`, `image`, `addPage`, `on('data'|'end'|'error')`, `end`.
- `deps.formatarMoeda?` — padrão `formatarMoedaBR` ("R$ 1.234,56").
- `DadosProposta` (tipos em `src/index.ts`):
  - obrigatórios: `titulo`, `empresa.nome`, `cliente.nome`, `itens` (pode ser vazio), `valores.total` (número finito);
  - empresa: `cnpj?`, `endereco?: string[]`, `contatos?: string[]`, `logo?` (Buffer/Uint8Array ou caminho; caminho inexistente ou `null` → texto `marca ?? nome` na cor `destaque`);
  - cliente: `cidadeUf?`, `telefone?`, `email?`, `endereco?`, `cep?`, `linhas?` (extras);
  - opcionais: `metadados`, `emissao`, `seloCliente`, `condicaoPagamento`, `resumo` (título, subtítulo, tabela com larguras em mm), `servicosInclusos`, `valores.linhas`, `valores.aVista` (rótulo, valor, chamada), `pagamentos.tabelas[]` (1 ou 2 pares de colunas; `marca` = texto em destaque depois do valor, ex. "s/ juros"), `economia` (indicadores + nota), `garantias`, `prazos` (linha `destaque` em negrito), `validade`, `notaGarantias`, `observacoes` (numeradas);
  - `rotulos?: Partial<RotulosProposta>` (padrões em português genérico: `ROTULOS_PADRAO`); `cores?: Partial<CoresProposta>` (padrões neutros: `CORES_PADRAO`).

## Saída
`Buffer` com o PDF (começa com `%PDF`). Fontes padrão Helvetica (WinAnsi: acentos do português funcionam).

## Erros
`ErroProposta` — sem `deps.PDFDocument`, sem `empresa.nome`/`cliente.nome`, `valores.total` não numérico. Erros do pdfkit (ex.: imagem inválida) rejeitam a Promise.

## Portas
Só `PDFDocument` (e `formatarMoeda`). Leitura de arquivo apenas para o `logo` dado como caminho (`existsSync`; depois o pdfkit lê).

## Não faz
Assinatura digital, fontes customizadas, cálculo de preço/parcelas (o host manda os valores prontos). Sem formato persistido.
