# Changelog — @lib/proposta-pdf

## 0.1.0 — 2026-11-24
- Primeira versão, extraída do PDF de orçamento do KeroSolar CRM (`src/lib/crm/belenus/orcamento-pdf.ts`) e generalizada: empresa, cliente, itens, valores, formas de pagamento, seções opcionais (economia, garantias, prazos, validade, observações), rótulos e cores por parâmetro; pdfkit injetado. 9 testes `node:test` (PDF válido, seções somem quando ausentes, acentos, logo em Buffer, quebra de página, erros).
