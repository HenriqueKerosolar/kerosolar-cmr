# Origem

- Projeto: KeroSolar CRM — `src/lib/crm/belenus/orcamento-pdf.ts` (Fase 3 do robô Belenus, 24/11/2026), que reproduzia com pdfkit o modelo de orçamento aprovado pelo dono.
- Atende a requisição **REQ-047** ("Gerador de PDF de proposta comercial (layout em caixas, tabelas)", KeroSolar CRM).
- Gate 0: `consultar pdf proposta` → nada. Existe `@lib/pdf-writer` (PDF puro, sem dependências), mas ele só embute JPEG (o logo do consumidor é PNG) e não tem o layout em caixas com tabelas lado a lado; reproduzir o modelo aprovado exigiria reescrever o desenho. Decisão: peça nova sobre pdfkit **injetado** (a peça continua sem dependência própria; `pdfkit` só como peer/dev para os testes).
- Generalização: tudo que era fixo (nome/CNPJ/endereço/contatos da empresa, textos do ramo, tabelas de garantia/prazo, cores da marca) virou parâmetro. O CRM passa os valores dele e o PDF sai igual ao anterior.
- Divergências não incorporadas: nenhuma regra de negócio (preço, parcelas, economia) — o host calcula e manda pronto.
- Consumidor: KeroSolar CRM (via `empacotar.mjs`, deploy no Railway).
