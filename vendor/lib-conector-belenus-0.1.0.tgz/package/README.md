# @lib/conector-belenus

Cliente da API interna do **Gerador Personalizado** da Belenus (a mesma que o site usa): login por e-mail, módulos, filtros e lista de inversores, conferência de potência, tipos de estrutura e estrutura, componentes CC/CA, etapa 6 "Confirmação", valor do seguro, opções de frete e "Salvar" a cotação. Inclui a leitura tolerante das respostas e os corpos no formato do site.

**Segurança (o coração da peça):**
- `ROTAS_PERMITIDAS` é uma lista fechada e congelada; `rotaPermitida()` bloqueia qualquer outra rota **antes do fetch** — finalizar pedido (`ConfirmarCarrinho`), carrinho, pagamento, seguro, frete, cupom e upload estão em `ROTA_PROIBIDA` para sempre. Os testes falham se qualquer rota proibida passar.
- Credenciais **sempre por parâmetro** (`loginBelenus({ email, senha })`); a peça não lê variáveis de ambiente. O token fica só na sessão em memória de quem chama.
- O log mostra só a "forma" das respostas (`formaResposta`): nomes de campos, tamanhos e amostra de campos de produto; token, e-mail, nome, documento e endereço nunca.
- Novas tentativas automáticas (opcionais) só nas consultas do catálogo; nunca em Confirmar/Salvar (gerariam cotação duplicada).

```ts
import { loginBelenus, clienteBelenus, listaDe } from '@lib/conector-belenus'

const deps = { tempoLimiteMs: 45_000, novasTentativasConsulta: 1 }
const sessao = await loginBelenus(credenciais, deps)   // { email, senha } vindos do cofre/ambiente do HOST
const api = clienteBelenus(sessao, deps)
const modulos = listaDe(await api.modulos({ site: '0001', potenciaProjeto: 4.34, modulo: '', qtde: 0, fabricantes: [{ fabricante: '' }] }), 'modulos')
```

A orquestração (qual etapa chamar, regras de negócio, onde gravar) é do host. Testes: `npm test` (Node >= 22.18, sem rede; `fetch` falso).
