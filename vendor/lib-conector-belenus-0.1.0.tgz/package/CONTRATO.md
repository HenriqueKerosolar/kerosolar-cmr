# Contrato — @lib/conector-belenus 0.1.0

## Rotas (rotas.ts)
`BELENUS_BASE` (`https://belenus.com.br/`), `ROTA_LOGIN`, `ROTA_CONFIRMAR`, `ROTA_VALOR_SEGURO`, `ROTA_BUSCAR_FRETES`, `ROTA_SALVAR_ORCAMENTO`, `ROTA_CATALOGO`, `ROTAS_PERMITIDAS` (14 caminhos exatos, congelada), `ROTA_PROIBIDA` (RegExp), `rotaPermitida(url)` (caminho exato da lista ou `StringBox/{n}`; outro host → false). **Mudar qualquer item = versão nova com revisão de segurança.**

## HTTP (cliente.ts)
- `chamarBelenus(rota, corpo, { token?, etapa, metodo?, logarForma?, cabecalhos? }, deps?)` → JSON. Rota fora da lista → `ErroBelenus` sem chamar o fetch (loga `[belenus] rota BLOQUEADA`).
- `loginBelenus({ email, senha }, deps?)` → `SessaoBelenus { token, mesesInatividade?, userType?, liberarComprasMinimas? }`. Credencial vazia → `ErroBelenus` sem rede.
- `clienteBelenus(sessao, deps?)` → `{ post, modulos, inversorFiltro, inversores, conferirPotenciaInversor, tiposEstrutura, estrutura, componentesCC, componentesCA, confirmar, valorSeguro, buscarFretes, salvarCotacao }` (cada um aceita `etapa`, rótulo para log/erros). `confirmar` envia `X-CarrinhoId: ""`.
- `DependenciasBelenus`: `fetch?` (padrão: o global, lido na hora), `log?: { info, erro }` (padrão console), `tempoLimiteMs?` (padrão 20000), `dicaAcessoNegado?` (texto somado ao erro 401/403), `novasTentativasConsulta?` (padrão 0; só quando `ehConsultaCatalogo(rota)` e só quando não houve resposta: tempo esgotado ou falha de rede).
- Erros (`ErroBelenus`, mensagens em português): tempo esgotado, falha de conexão, 401/403, HTTP fora de 2xx (com `messages` da Belenus), `isSucceed: false`, login sem token.

## Leitura (leitura.ts)
`ehObj`, `num`, `campo`, `listaDe`, `dadosDe`, `mensagensBelenus`, `descricaoDe`, `codigoDe`, `qtdeDe`, `precoDe`, `potenciaW`, `potenciaKw`, `ordenarComoSite`, `potenciaModuloW`, `potenciaInversorKw`, `marcaDe`, `qtdSugeridaDe`, `ehMicroInversor`, `ehMarca`, `LEITOR_INVERSOR` (formato de `@lib/dimensionamento-solar`), `opcaoTexto`, `escolherOpcao`, `RE_ON_GRID`, `RE_NAO_ON_GRID`, `reLigacao`, `reTensao`, `ItemKit`, `paraItem`, `semRepetidos`, `formaResposta`.

## Confirmação (confirmacao.ts)
`corpoConfirmar(DadosConfirmar)`, `corpoBuscarFretes(carrinho, { site, destino, sessao })` (documento do cliente nunca vai), `corpoSalvarOrcamento(carrinho, { nome, destino, freteOpcao?, entrega? })` (não troca o cliente de faturamento), `lerConfirmacao(resp, { frete?, seguro? }, log?)` → `Confirmacao` (total = produtos + frete + seguro; sem total → `Error`), `numeroCotacaoDe`, `freteEntregaNoCliente`, `valorSeguroDe`.

## Não faz
Ler credenciais de ambiente, guardar token, decidir regras do kit, finalizar pedido. Sem formato persistido.
