# Changelog — @lib/conector-belenus

## 0.1.0 — 2026-11-24
- Primeira versão, extraída do KeroSolar CRM (`src/lib/crm/belenus/api.ts`, `regras.ts`, `cotar.ts`): lista fechada de rotas e trava antes do fetch, login com credenciais por parâmetro, cliente por sessão com todas as etapas do Gerador Personalizado, leitura tolerante, log só de forma, corpos de Confirmar/BuscarFretes/Salvar e leitura da Confirmação. Novo: tempo limite configurável e novas tentativas só para consultas do catálogo. 24 testes `node:test` (inclui os de segurança de rotas e de log).
