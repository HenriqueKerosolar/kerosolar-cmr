# Origem

- Projeto: KeroSolar CRM — `src/lib/crm/belenus/api.ts` (cliente HTTP), `regras.ts` (rotas permitidas/proibidas, `formaResposta`, leitura tolerante, Confirmação, corpo do Salvar) e `cotar.ts` (corpos do Confirmar e do BuscarFretes). Formatos levantados do bundle público do site (serviço "monteSeuKitService").
- Gate 0: `consultar belenus` → nada.
- Mudanças na extração: credenciais deixam de vir de variáveis de ambiente (agora parâmetro); `fetch`, log e tempo limite injetáveis; dica do erro 401 por parâmetro; métodos nomeados por etapa (`clienteBelenus`). A lista de rotas e a expressão de proibidas foram copiadas **sem alteração**, com todos os testes de bloqueio.
- Pedido do dono durante a extração (24/11/2026): Belenus lenta → o CRM passa 45 s e 1 nova tentativa; a peça só repete consultas do catálogo (`ehConsultaCatalogo`), nunca Confirmar/Salvar/seguro/frete/login.
- Ficaram no CRM: a orquestração da cotação (ordem das etapas, avisos, regras da KeroSolar), leitura das credenciais e da filial no ambiente, nota interna e Prisma.
- Riscos: API interna não documentada da Belenus (pode mudar sem aviso); peça sensível (trava de compra) — qualquer mudança em rotas exige versão nova e revisão de segurança.
- Consumidor: KeroSolar CRM.
